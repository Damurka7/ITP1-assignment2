package simulator.do_not_change;

public interface SmallCase {
	
	// from small letter to Capital after a certain number of iterations
	public abstract void upgrade();

}
