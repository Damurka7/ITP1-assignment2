package simulator.do_not_change;

public interface Aggressive {
	
	// Move towards weaker symbols only - within the sightDistance
	public abstract void attackSmart();
	
}