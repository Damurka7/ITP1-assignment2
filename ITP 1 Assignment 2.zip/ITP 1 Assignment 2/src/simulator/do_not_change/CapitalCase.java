package simulator.do_not_change;

public interface CapitalCase {
	
	// Jump to another random position even if it is out of the sightDistance
	public abstract void jump();

}
