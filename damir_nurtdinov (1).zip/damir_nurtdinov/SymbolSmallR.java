package simulator.damir_nurtdinov;

import simulator.do_not_change.Passive;
import simulator.do_not_change.Position;
import simulator.do_not_change.SmallCase;
import simulator.do_not_change.Symbol;

import java.util.Random;

import static simulator.do_not_change.WorldController.MAX_COLS;
import static simulator.do_not_change.WorldController.MAX_ROWS;




public class SymbolSmallR extends Symbol implements SmallCase, Passive {
    final int ESCAPE_DISTANCE=1;
    final int MOVE_DISTANCE=1;
    final int MOVE_BREED_DISTANCE=1;
    Simulator simulator = new Simulator();//to use plotWorld() method from class Simulator

    /**
     * each symbol has its own hashcode
     */
    public SymbolSmallR() {
        this.idSymbol = Simulator.COUNTER;

    }

    Position current = new Position(0,0);

    /**
     * checks for the symbol which can kill it
     * randomly chooses position to go away from this symbol within its escape distance
     */
    @Override
    public void escape() {
        sightDistance=ESCAPE_DISTANCE;
        current.column = getPosition().column;
        current.row = getPosition().row;
        int instant_row = getPosition().row;
        int instant_column = getPosition().column;

        Random rnd = new Random();
        int counter=0;

        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {//to find a rocks
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    counter++;
                    if(Simulator.charValues[instant_row + i][instant_column + j] == 'r' || Simulator.charValues[instant_row + i][instant_column + j] == 'R'){
                        counter--;
                    }
                }
            }
        }

        int new_counter =0;
        int new_position =0;
        if(counter>1){
            new_position = rnd.nextInt(counter-1);
        }
        else{
            new_position= 0;
        }
        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {//to find a rocks
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    if(Simulator.charValues[instant_row + i][instant_column + j] != 'r' || Simulator.charValues[instant_row + i][instant_column + j] != 'R'){
                        if(new_counter==new_position){
                            current.row = instant_row + i;
                            current.column = instant_column + j;
                            this.setPosition(current);
                            break;
                        }
                        new_counter++;
                    }
                }
            }
        }
    }


    /**
     * looks for the similar breed
     * then goes to the next position of his "friend" if it can kill the symbol on this next position
     */
    @Override
    public void moveBreed() {// move to the closest symbol with a similar breed
        sightDistance=MOVE_BREED_DISTANCE;
        current.column = getPosition().column;
        current.row = getPosition().row;
        int instant_row = getPosition().row;
        int instant_column = getPosition().column;
        Random rnd = new Random();
        int counter=0;

        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    if(Simulator.charValues[instant_row + i][instant_column + j] == 'r' || Simulator.charValues[instant_row + i][instant_column + j] == 'R'){
                        break;//if it sees a similar breed, then it stops searching
                    }
                    counter++;
                }
            }
        }

        counter++;
        int new_counter=0;//it will choose the next position after similar breed
        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    if(Simulator.charValues[instant_row + i][instant_column + j] != 'r' || Simulator.charValues[instant_row + i][instant_column + j] != 'R'){
                        if(counter==new_counter&&i!=0&&(Simulator.charValues[instant_row + i][instant_column + j] != 'P' || Simulator.charValues[instant_row + i][instant_column + j] != 'p')){//or don't change if it is the same row
                            current.row = instant_row + i;
                            current.column = instant_column + j;
                            this.setPosition(current);
                            break;
                        }
                    }
                }
            }
        }

    }


    /**
     * becomes to symbol with a capital class
     */
    @Override
    public void upgrade() {
        int instant_row = getPosition().row;
        int instant_column = getPosition().column;
        Simulator.charValues[instant_row][instant_column] = 'R';
    }

    /**
     * moves randomly within its move distance (sightDistance)
     * at the beginning it checks how much position does it have
     * then randomly chooses one of it
     */
    @Override
    public void move() {
        sightDistance=MOVE_DISTANCE;
        current.column = getPosition().column;
        current.row = getPosition().row;
        int instant_row = getPosition().row;
        int instant_column = getPosition().column;
        Random rnd = new Random();
        int counter=0;

        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {//to find a scissors
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    counter++;
                }
            }
        }
        // System.out.println("my old coord "+getPosition().row +" "+  getPosition().column);
        int new_counter =0;
        int new_position = rnd.nextInt(counter-1);
        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {//to find a scissors
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    if(new_counter==new_position){
                        current.row = instant_row + i;
                        current.column = instant_column + j;
                        this.setPosition(current);
                        break;
                    }
                    new_counter++;
                }
            }
        }

    }

    /**
     * creates a new Symbol on place of dead one
     */
    @Override
    public void die() {
        int row = getPosition().row;
        int column = getPosition().column;
        Simulator.initializeCell(row,column, simulator.plotWorld());
    }
}
