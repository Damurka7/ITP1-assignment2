package simulator.damir_nurtdinov;

import com.sun.istack.internal.NotNull;
import simulator.do_not_change.*;

import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.List;
import java.util.Random;

public class Simulator extends WorldController {
    final int NUMBER_OF_LIFES_CAPITAL_R = 2;
    final int NUMBER_OF_LIFES_SMALL_R = 2;
    final int NUMBER_OF_LIFES_CAPITAL_S = 2;
    final int NUMBER_OF_LIFES_SMALL_S = 2;
    final int NUMBER_OF_LIFES_CAPITAL_P = 2;
    final int NUMBER_OF_LIFES_SMALL_P = 2;
    public static int COUNTER = 0;
    private final char[] letters = {CAPITAL_R, CAPITAL_P, CAPITAL_S, SMALL_R, SMALL_P, SMALL_S}; // array of letters to plot the world randomly
    public static Symbol[][] world = new Symbol[MAX_ROWS][MAX_COLS]; //symbol world
    public static char[][] charValues = new char[MAX_ROWS][MAX_COLS]; //corresponding char world
    static HashSet<Symbol> set = new HashSet<>();
    public static void main(String[] args){

        Simulator currentWorld = new Simulator();
        currentWorld.createWorld();
        currentWorld.printWorld();

        for (int i = 0; i < 1000; i++) {//1000 - number of iteration
            currentWorld.doOneIteration(i+1);
            currentWorld.printWorld();
        }
    }

    /**
     * creating world 10*10 and fill it randomly
     */
    public void createWorld() {
        for (int i = 0; i < MAX_ROWS; i++) { //plotting the world
            for (int j = 0; j < MAX_COLS; j++) {
                initializeCell(i, j, plotWorld());
            }
        }
    }

    /**
     *creating corresponding symbol for letter
     * @param ss - String Symbol
     * @return - return object with corresponding class
     */
    @NotNull
    public static Symbol createCorrespondingSymbolObject(String ss) {
        Symbol res = null;
        switch (ss) {
            case "R":
                res = new SymbolCapitalR();
                break;
            case "r":
                res = new SymbolSmallR();
                break;
            case "S":
                res = new SymbolCapitalS();
                break;
            case "s":
                res = new SymbolSmallS();
                break;
            case "P":
                res = new SymbolCapitalP();
                break;
            default:
                res = new SymbolSmallP();
                break;
        }
        return res;
    }

    /**
     * printing each cell of a world
     */
    public void printWorld() {
        for (int i = 0; i < MAX_ROWS; i++) {
            for (int j = 0; j < MAX_COLS; j++) {
                System.out.print(charValues[i][j] + " ");
            }
            System.out.println();
        }
    }

    /**
     *  it starts checking what symbol we are considering and then it does all available methods for this symbol
     *  (some symbols do smth not every iteration)
     *  it was done to make world more stable
     *  method randomly creates new symbol on the place where  was another one, if it has moved
     *  aggressive symbols can attack firstly and only then they can do another methods
     *  passive symbols can escape firstly
     * @param numOfIteration we need to know it for some letters
     */
    public void doOneIteration(int numOfIteration) {
        for (int i = 0; i < MAX_ROWS; i++) {
            for (int j = 0; j < MAX_COLS; j++) {
                Symbol letter = world[i][j];
                if (letter.getPosition()==null) {//to find some errors
                    System.err.printf("position is null row %d column %d\n", i, j);
                    System.err.flush();
                }
                char correspondingChar = charValues[letter.getPosition().row][letter.getPosition().column];
                if (correspondingChar == 'R') {
                    if (!(letter instanceof SymbolCapitalR)) { //creating array with letters (not symbols!) safety
                        world[i][j] = createCorrespondingSymbolObject("R");//kinda doublecheck
                        initializeCell(i, j, "R");
                        letter = world[i][j];
                    }
                    SymbolCapitalR R = (SymbolCapitalR) letter;
                    int oldRow = R.getPosition().row;
                    int oldColumn = R.getPosition().column;

                    R.attackSmart();
                    int newRow = R.getPosition().row;
                    int newColumn = R.getPosition().column;
                    if(oldColumn!=newColumn&&oldRow!=newRow) {//if it has attacked
                        charValues[newRow][newColumn] = charValues[i][j];//creating letter on a new position
                        world[newRow][newColumn] = R;//creating corresponding symbol on a new position
                        initializeCell(i, j, plotWorld());//old place of R, here we are creating random letter
                    }


                    R.move();
                    newRow = R.getPosition().row;
                    newColumn = R.getPosition().column;//getting new position
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = R;
                    initializeCell(i,j,plotWorld());//old place of R

                    R.becomeOlder();
                    if (R.getNumberIterationsAlive() >= NUMBER_OF_LIFES_CAPITAL_R) {
                        R.die();//we have created a new symbol
                        charValues[newRow][newColumn] = charValues[i][j];//here we add this new symbol to array
                    }
                }
                if (correspondingChar == 'r') {
                    if (!(letter instanceof SymbolSmallR)) { //creating array with letters (not symbols!) safety
                        world[i][j] = createCorrespondingSymbolObject("r");
                        initializeCell(i, j, "r");
                        letter = world[i][j];
                    }
                    SymbolSmallR r = (SymbolSmallR) letter;
                    r.escape();
                    int newRow = r.getPosition().row;
                    int newColumn = r.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = r;
                    Simulator.initializeCell(i,j,plotWorld());//old place of r

                    r.moveBreed();
                    newRow = r.getPosition().row;
                    newColumn = r.getPosition().column;//getting new position
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = r;
                    Simulator.initializeCell(i,j,plotWorld());//old place of r

                    if(numOfIteration%2==0) {//moves every even number of iteration, it is better for stability of the world
                        r.move();
                    }

                    if(numOfIteration%2==0) {//upgrades every even number of iteration, it is better for stability of the world
                        r.upgrade();
                    }
                    r.becomeOlder();
                    if (r.getNumberIterationsAlive() >= NUMBER_OF_LIFES_SMALL_R) {
                        r.die();
                        charValues[newRow][newColumn] = charValues[i][j];

                    }
                }
                if (correspondingChar == 'S') {
                    if (!(letter instanceof SymbolCapitalS)) { //creating array with letters (not symbols!) safety
                        world[i][j] = createCorrespondingSymbolObject("S");
                        initializeCell(i, j, "S");
                        letter = world[i][j];
                    }
                    SymbolCapitalS S = (SymbolCapitalS) letter;
                    int oldRow = S.getPosition().row;
                    int oldColumn = S.getPosition().column;

                    S.attackSmart();
                    int newRow = S.getPosition().row;
                    int newColumn = S.getPosition().column;

                    if(oldColumn!=newColumn&&oldRow!=newRow) {//if it has attacked
                        charValues[newRow][newColumn] = charValues[i][j];
                        world[newRow][newColumn] = S;
                        initializeCell(i, j, plotWorld());//old place of R
                    }

                    S.move();
                    newRow = S.getPosition().row;
                    newColumn = S.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = S;
                    initializeCell(i,j,plotWorld());//old place of S

                    S.jump();
                    newRow = S.getPosition().row;
                    newColumn = S.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = S;
                    initializeCell(i,j,plotWorld());

                    S.becomeOlder();
                    if (S.getNumberIterationsAlive() >= NUMBER_OF_LIFES_CAPITAL_S) {
                        S.die();
                        charValues[newRow][newColumn] = charValues[i][j];
                    }
                }

                if (correspondingChar == 's') {
                    if (!(letter instanceof SymbolSmallS)) { //creating array with letters (not symbols!) safety
                        world[i][j] = createCorrespondingSymbolObject("s");
                        initializeCell(i, j, "s");
                        letter = world[i][j];
                    }
                    SymbolSmallS s = (SymbolSmallS) letter;
                    int oldRow = s.getPosition().row;
                    int oldColumn = s.getPosition().column;

                    s.attackSmart();
                    int newRow = s.getPosition().row;
                    int newColumn = s.getPosition().column;

                    if(oldColumn!=newColumn&&oldRow!=newRow) {//if it has attacked
                        charValues[newRow][newColumn] = charValues[i][j];
                        world[newRow][newColumn] = s;
                        initializeCell(i, j, plotWorld());//old place of s
                    }

                    s.move();
                    newRow = s.getPosition().row;
                    newColumn = s.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = s;
                    initializeCell(i,j,plotWorld());//old place of s

                    s.jump();
                    newRow = s.getPosition().row;
                    newColumn = s.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = s;
                    initializeCell(i,j,plotWorld());

                    s.becomeOlder();
                    if (s.getNumberIterationsAlive() >= NUMBER_OF_LIFES_SMALL_S) {
                        s.die();
                        charValues[newRow][newColumn] = charValues[i][j];
                    }
                }

                if (correspondingChar == 'P') {
                    if (!(letter instanceof SymbolCapitalP)) { //creating array with letters (not symbols!) safety
                        world[i][j] = createCorrespondingSymbolObject("P");
                        initializeCell(i, j, "P");
                        letter = world[i][j];
                    }
                    SymbolCapitalP P = (SymbolCapitalP) letter;



                    int newRow;
                    int newColumn;

                    P.escape();
                    newRow = P.getPosition().row;
                    newColumn = P.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = P;
                    initializeCell(i,j,plotWorld());

                    P.moveBreed();
                    newRow = P.getPosition().row;
                    newColumn = P.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = P;
                    Simulator.initializeCell(i,j,plotWorld());//old place of P

                    P.move();
                    newRow = P.getPosition().row;
                    newColumn = P.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = P;
                    initializeCell(i,j,plotWorld());//old place of P

                    P.jump();
                    newRow = P.getPosition().row;
                    newColumn = P.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = P;
                    initializeCell(i,j,plotWorld());

                    P.becomeOlder();
                    if (P.getNumberIterationsAlive() >= NUMBER_OF_LIFES_CAPITAL_P) {
                        P.die();
                        charValues[newRow][newColumn] = charValues[i][j];
                    }
                }

                if (correspondingChar == 'p') {
                    if (!(letter instanceof SymbolSmallP)) { //creating array with letters (not symbols!) safety
                        world[i][j] = createCorrespondingSymbolObject("p");
                        initializeCell(i, j, "p");
                        letter = world[i][j];
                    }
                    SymbolSmallP p = (SymbolSmallP) letter;
                    int oldRow = p.getPosition().row;
                    int oldColumn = p.getPosition().column;

                    p.attackSmart();

                    int newRow = p.getPosition().row;
                    int newColumn = p.getPosition().column;

                    if(oldColumn!=newColumn&&oldRow!=newRow) {//if it has attacked
                        charValues[newRow][newColumn] = charValues[i][j];
                        world[newRow][newColumn] = p;
                        initializeCell(i, j, plotWorld());//old place of p
                    }

                    p.move();
                    newRow = p.getPosition().row;
                    newColumn = p.getPosition().column;
                    charValues[newRow][newColumn] = charValues[i][j];
                    world[newRow][newColumn] = p;
                    initializeCell(i,j,plotWorld());//old place of p

                    p.becomeOlder();
                    if (p.getNumberIterationsAlive() >= NUMBER_OF_LIFES_SMALL_P) {
                        p.die();
                        charValues[newRow][newColumn] = charValues[i][j];
                    }

                    if(numOfIteration%2==0) {//upgrades every even number of iteration, it is better for stability of the world
                        p.upgrade();
                    }
                }

            }
        }
        System.out.println();
    }


    @Override
    public void symbolsMove(List<Symbol> symbols) {

    }

    @Override
    public void symbolsDie(List<Symbol> symbols) {

    }

    @Override
    public void smallCaseUpgrade(List<SmallCase> symbols) {

    }

    @Override
    public void capitalCaseJump(List<CapitalCase> symbols) {

    }

    @Override
    public void passiveEscape(List<Passive> symbols) {

    }

    @Override
    public void passiveBreed(List<Passive> symbols) {

    }

    @Override
    public void aggressiveAttackSmart(List<Aggressive> symbols) {

    }

    /**
     * creates letter randomly
     * @return random letter
     */
    @Override
    public String plotWorld() {// I can't use not static methods in static main
        Random rnd = new Random();//choosing one letter randomly
        return String.valueOf(letters[rnd.nextInt(6)]);
    }

    /**
     *
     * @param i row
     * @param j column
     * @param desiredLetter letter which you want to create
     */
    public static void initializeCell(int i, int j, String desiredLetter) {//передавай стринг вместо булина
        charValues[i][j] = desiredLetter.toCharArray()[0];
        world[i][j] = createCorrespondingSymbolObject(desiredLetter);
        set.add(world[i][j]);

        COUNTER++;//adding one to a hashcode of symbol
        Position curSym = new Position(i,j);
        curSym.column = j;
        curSym.row = i;
        world[i][j].setPosition(curSym);
        return;
    }
}
