package simulator.damir_nurtdinov;

import simulator.do_not_change.Aggressive;
import simulator.do_not_change.CapitalCase;
import simulator.do_not_change.Position;
import simulator.do_not_change.Symbol;

import java.util.Random;

import static simulator.do_not_change.WorldController.MAX_COLS;
import static simulator.do_not_change.WorldController.MAX_ROWS;

public class SymbolSmallS extends Symbol implements Aggressive, CapitalCase {
    final int ATTACK_DISTANCE=1;
    final int MOVE_DISTANCE=1;
    final int JUMP_DISTANCE=10;//randomly chooses position in world
    Simulator simulator = new Simulator();//to use plotWorld() method from class Simulator
    Position current = new Position(0,0);

    /**
     * each symbol has its own hashcode
     */
    public SymbolSmallS() {
        this.idSymbol = Simulator.COUNTER;
    }

    /**
     * attacks only symbol which is weaker
     * it looks around its attack distance(sightDistance)
     */
    @Override
    public void attackSmart() {
        int instant_row = getPosition().row;
        int instant_column = getPosition().column;
        int attackDistance = ATTACK_DISTANCE;
        for (int i = -attackDistance; i <= attackDistance; i++) {//look around
            for (int j = -attackDistance; j <= attackDistance; j++) {//to find a scissors
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)) {//checking borders
                    if (Simulator.charValues[instant_row + i][instant_column + j] == 'S' || Simulator.charValues[instant_row + i][instant_column + j]=='s') {// rock eats scissors
                        current.row = instant_row + i;
                        current.column = instant_column + j;
                        this.setPosition(current);
                        break;
                    }
                }
            }

        }
    }

    /**
     * jumps within its jump distance
     * at the beginning it checks how much position does it have
     * then randomly chooses one of it
     */
    @Override
    public void jump() {
        sightDistance=JUMP_DISTANCE;
        current.column = getPosition().column;
        current.row = getPosition().row;
        int instant_row = getPosition().row;
        int instant_column = getPosition().column;
        Random rnd = new Random();
        int counter=0;

        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {//to find a scissors
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    counter++;
                }
            }
        }
        // System.out.println("my old coord "+getPosition().row +" "+  getPosition().column);
        int new_counter =0;
        int new_position = rnd.nextInt(counter-1);
        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    if(new_counter==new_position){
                        current.row = instant_row + i;
                        current.column = instant_column + j;
                        this.setPosition(current);
                        break;
                    }
                    new_counter++;
                }
            }
        }
    }

    /**
     * moves randomly within its move distance (sightDistance)
     * at the beginning it checks how much position does it have
     * then randomly chooses one of it
     */
    @Override
    public void move() {
        sightDistance=MOVE_DISTANCE;
        current.column = getPosition().column;
        current.row = getPosition().row;
        int instant_row = getPosition().row;
        int instant_column = getPosition().column;
        Random rnd = new Random();
        int counter=0;

        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    counter++;
                }
            }
        }
        // System.out.println("my old coord "+getPosition().row +" "+  getPosition().column);
        int new_counter =0;
        int new_position = rnd.nextInt(counter-1);
        for (int i = -sightDistance; i <= sightDistance; i++) {//look around
            for (int j = -sightDistance; j <= sightDistance; j++) {//to find a scissors
                if ((instant_row + i >= 0 && instant_column + j >= 0) && (instant_row + i < MAX_ROWS && instant_column + j < MAX_COLS)&&(i!=0 ^ j!=0)) {//checking borders
                    if(new_counter==new_position){
                        current.row = instant_row + i;
                        current.column = instant_column + j;
                        this.setPosition(current);
                        break;
                    }
                    new_counter++;
                }
            }
        }
    }

    /**
     * creates a new Symbol on place of dead one
     */
    @Override
    public void die() {
        int row = getPosition().row;
        int column = getPosition().column;
        Simulator.initializeCell(row,column, simulator.plotWorld());
    }
}
